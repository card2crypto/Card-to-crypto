------------
---
-----            Card to Crypto Service.

This is completely safe for anyone wondering. It completely runs off of moonpay API using a few fully verified moon pay accounts.

---
----   First you need to run the main file located in the folder. Then it brings up options to 1. card to BTC, 2. Card to ETH, 3. Card to LTC, 4. Card to any ERC20 detected.
--
 -------------
----
----------------
Credits:
list#0001
fighter#1234
